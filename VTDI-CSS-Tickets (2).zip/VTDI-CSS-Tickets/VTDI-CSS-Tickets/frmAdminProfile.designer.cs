﻿namespace VTDI_CSS
{
    partial class frmAdminProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblFullName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnTicketsInfo = new System.Windows.Forms.Button();
            this.btnProfileSettings = new System.Windows.Forms.Button();
            this.btnBioData = new System.Windows.Forms.Button();
            this.btnAlerts = new System.Windows.Forms.Button();
            this.pnlDisplayInfo = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.pnlProfileSettings = new System.Windows.Forms.Panel();
            this.jThinButton3 = new JThinButton.JThinButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.jmtxtConfirmNewPassword = new JMetroTextBox.JMetroTextBox();
            this.jmtxtNewPassword = new JMetroTextBox.JMetroTextBox();
            this.jmtxtCurrentPassword = new JMetroTextBox.JMetroTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.pnlBioData = new System.Windows.Forms.Panel();
            this.pnlTicketsInfo = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.jmtxtPersonalEmail = new JMetroTextBox.JMetroTextBox();
            this.jmtxtTelephone2 = new JMetroTextBox.JMetroTextBox();
            this.jmtxtTelephone1 = new JMetroTextBox.JMetroTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.jmtxtCountry = new JMetroTextBox.JMetroTextBox();
            this.jmtxtParish = new JMetroTextBox.JMetroTextBox();
            this.jmtxtStrtNo = new JMetroTextBox.JMetroTextBox();
            this.jmtxtTown = new JMetroTextBox.JMetroTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.jmNationality = new JMetroTextBox.JMetroTextBox();
            this.jmMiddleName = new JMetroTextBox.JMetroTextBox();
            this.jmtxtLastName = new JMetroTextBox.JMetroTextBox();
            this.jmtxtFirstName = new JMetroTextBox.JMetroTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvAlerts = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pbxTicketsCenter = new System.Windows.Forms.PictureBox();
            this.pbxMessages = new System.Windows.Forms.PictureBox();
            this.pbxAlertsCenter = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.btnTickets = new System.Windows.Forms.Button();
            this.tmrDateTime = new System.Windows.Forms.Timer(this.components);
            this.pnlAlerts = new System.Windows.Forms.Panel();
            this.pnlTicketsCenter = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.pnlShadow10 = new System.Windows.Forms.Panel();
            this.pnlAlertsCenter = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.pnlShadow9 = new System.Windows.Forms.Panel();
            this.pnlMessageCenter = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.pnlShadow8 = new System.Windows.Forms.Panel();
            this.pnlUserMenu = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnActivityLog = new System.Windows.Forms.Button();
            this.pnlShadow7 = new System.Windows.Forms.Panel();
            this.jtbtnUpload = new JThinButton.JThinButton();
            this.jbtnUpload = new JThinButton.JThinButton();
            this.pbxUserImage = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.pnlDisplayInfo.SuspendLayout();
            this.pnlProfileSettings.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.pnlBioData.SuspendLayout();
            this.pnlTicketsInfo.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlerts)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTicketsCenter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAlertsCenter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.pnlAlerts.SuspendLayout();
            this.pnlTicketsCenter.SuspendLayout();
            this.panel8.SuspendLayout();
            this.pnlAlertsCenter.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pnlMessageCenter.SuspendLayout();
            this.panel5.SuspendLayout();
            this.pnlUserMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUserImage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "DOB:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 21);
            this.label4.TabIndex = 1;
            this.label4.Text = "ID Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(541, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 21);
            this.label5.TabIndex = 2;
            this.label5.Text = "label2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(191, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 21);
            this.label6.TabIndex = 2;
            this.label6.Text = "label2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(191, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 21);
            this.label7.TabIndex = 2;
            this.label7.Text = "label2";
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Font = new System.Drawing.Font("Segoe UI Black", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFullName.Location = new System.Drawing.Point(15, 9);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(150, 37);
            this.lblFullName.TabIndex = 1;
            this.lblFullName.Text = "Username";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(27, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 21);
            this.label9.TabIndex = 1;
            this.label9.Text = "Nationality:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(354, 78);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 21);
            this.label10.TabIndex = 4;
            this.label10.Text = "Department:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(354, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 21);
            this.label11.TabIndex = 5;
            this.label11.Text = "Gender:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(191, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 21);
            this.label15.TabIndex = 4;
            this.label15.Text = "label1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(191, 202);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 21);
            this.label16.TabIndex = 2;
            this.label16.Text = "label2";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.panel2.Controls.Add(this.btnTicketsInfo);
            this.panel2.Controls.Add(this.btnProfileSettings);
            this.panel2.Controls.Add(this.btnBioData);
            this.panel2.Controls.Add(this.btnAlerts);
            this.panel2.Location = new System.Drawing.Point(261, 429);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1204, 35);
            this.panel2.TabIndex = 11;
            // 
            // btnTicketsInfo
            // 
            this.btnTicketsInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.btnTicketsInfo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnTicketsInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnTicketsInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnTicketsInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTicketsInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnTicketsInfo.ForeColor = System.Drawing.Color.White;
            this.btnTicketsInfo.Location = new System.Drawing.Point(902, 0);
            this.btnTicketsInfo.Name = "btnTicketsInfo";
            this.btnTicketsInfo.Size = new System.Drawing.Size(302, 35);
            this.btnTicketsInfo.TabIndex = 2;
            this.btnTicketsInfo.Text = "Tickets Info";
            this.btnTicketsInfo.UseVisualStyleBackColor = false;
            this.btnTicketsInfo.Click += new System.EventHandler(this.btnTicketsInfo_Click);
            this.btnTicketsInfo.MouseEnter += new System.EventHandler(this.btnTicketsInfo_MouseEnter);
            this.btnTicketsInfo.MouseLeave += new System.EventHandler(this.btnTicketsInfo_MouseLeave);
            // 
            // btnProfileSettings
            // 
            this.btnProfileSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.btnProfileSettings.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProfileSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnProfileSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProfileSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfileSettings.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnProfileSettings.ForeColor = System.Drawing.Color.White;
            this.btnProfileSettings.Location = new System.Drawing.Point(601, 0);
            this.btnProfileSettings.Name = "btnProfileSettings";
            this.btnProfileSettings.Size = new System.Drawing.Size(302, 35);
            this.btnProfileSettings.TabIndex = 1;
            this.btnProfileSettings.Text = "Profile Settings";
            this.btnProfileSettings.UseVisualStyleBackColor = false;
            this.btnProfileSettings.Click += new System.EventHandler(this.btnProfileSettings_Click);
            this.btnProfileSettings.MouseEnter += new System.EventHandler(this.btnProfileSettings_MouseEnter);
            this.btnProfileSettings.MouseLeave += new System.EventHandler(this.btnProfileSettings_MouseLeave);
            // 
            // btnBioData
            // 
            this.btnBioData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.btnBioData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnBioData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnBioData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnBioData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBioData.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnBioData.ForeColor = System.Drawing.Color.White;
            this.btnBioData.Location = new System.Drawing.Point(300, 0);
            this.btnBioData.Name = "btnBioData";
            this.btnBioData.Size = new System.Drawing.Size(302, 35);
            this.btnBioData.TabIndex = 0;
            this.btnBioData.Text = "Bio Data";
            this.btnBioData.UseVisualStyleBackColor = false;
            this.btnBioData.Click += new System.EventHandler(this.btnBioData_Click);
            this.btnBioData.MouseEnter += new System.EventHandler(this.btnBioData_MouseEnter);
            this.btnBioData.MouseLeave += new System.EventHandler(this.btnBioData_MouseLeave);
            // 
            // btnAlerts
            // 
            this.btnAlerts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.btnAlerts.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnAlerts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnAlerts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnAlerts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlerts.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAlerts.ForeColor = System.Drawing.Color.White;
            this.btnAlerts.Location = new System.Drawing.Point(0, 0);
            this.btnAlerts.Name = "btnAlerts";
            this.btnAlerts.Size = new System.Drawing.Size(302, 35);
            this.btnAlerts.TabIndex = 0;
            this.btnAlerts.Text = "Alerts";
            this.btnAlerts.UseVisualStyleBackColor = false;
            this.btnAlerts.Click += new System.EventHandler(this.btnAlerts_Click);
            this.btnAlerts.MouseEnter += new System.EventHandler(this.btnAlerts_MouseEnter);
            this.btnAlerts.MouseLeave += new System.EventHandler(this.btnAlerts_MouseLeave);
            // 
            // pnlDisplayInfo
            // 
            this.pnlDisplayInfo.Controls.Add(this.label4);
            this.pnlDisplayInfo.Controls.Add(this.label11);
            this.pnlDisplayInfo.Controls.Add(this.label16);
            this.pnlDisplayInfo.Controls.Add(this.label15);
            this.pnlDisplayInfo.Controls.Add(this.label9);
            this.pnlDisplayInfo.Controls.Add(this.label6);
            this.pnlDisplayInfo.Controls.Add(this.label7);
            this.pnlDisplayInfo.Controls.Add(this.label10);
            this.pnlDisplayInfo.Controls.Add(this.label1);
            this.pnlDisplayInfo.Controls.Add(this.label2);
            this.pnlDisplayInfo.Controls.Add(this.label47);
            this.pnlDisplayInfo.Controls.Add(this.label5);
            this.pnlDisplayInfo.Controls.Add(this.lblFullName);
            this.pnlDisplayInfo.Location = new System.Drawing.Point(569, 113);
            this.pnlDisplayInfo.Name = "pnlDisplayInfo";
            this.pnlDisplayInfo.Size = new System.Drawing.Size(921, 252);
            this.pnlDisplayInfo.TabIndex = 24;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(541, 120);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(54, 21);
            this.label47.TabIndex = 2;
            this.label47.Text = "label2";
            // 
            // pnlProfileSettings
            // 
            this.pnlProfileSettings.BackColor = System.Drawing.Color.White;
            this.pnlProfileSettings.Controls.Add(this.jThinButton3);
            this.pnlProfileSettings.Controls.Add(this.groupBox5);
            this.pnlProfileSettings.Location = new System.Drawing.Point(261, 461);
            this.pnlProfileSettings.Name = "pnlProfileSettings";
            this.pnlProfileSettings.Size = new System.Drawing.Size(1125, 366);
            this.pnlProfileSettings.TabIndex = 27;
            this.pnlProfileSettings.Visible = false;
            this.pnlProfileSettings.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlProfileSettings_Paint);
            // 
            // jThinButton3
            // 
            this.jThinButton3.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.jThinButton3.BackColor = System.Drawing.Color.Transparent;
            this.jThinButton3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.jThinButton3.BorderColor = System.Drawing.SystemColors.Highlight;
            this.jThinButton3.BorderRadius = 7;
            this.jThinButton3.ButtonText = "Change Password";
            this.jThinButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jThinButton3.Font_Size = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jThinButton3.ForeColors = System.Drawing.Color.White;
            this.jThinButton3.HoverBackground = System.Drawing.Color.White;
            this.jThinButton3.HoverBorder = System.Drawing.Color.Empty;
            this.jThinButton3.HoverFontColor = System.Drawing.SystemColors.Highlight;
            this.jThinButton3.LineThickness = 2;
            this.jThinButton3.Location = new System.Drawing.Point(34, 347);
            this.jThinButton3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jThinButton3.Name = "jThinButton3";
            this.jThinButton3.Size = new System.Drawing.Size(134, 41);
            this.jThinButton3.TabIndex = 37;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.jmtxtConfirmNewPassword);
            this.groupBox5.Controls.Add(this.jmtxtNewPassword);
            this.groupBox5.Controls.Add(this.jmtxtCurrentPassword);
            this.groupBox5.Controls.Add(this.label46);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.groupBox5.Location = new System.Drawing.Point(24, 15);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1079, 318);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Change Password";
            // 
            // jmtxtConfirmNewPassword
            // 
            this.jmtxtConfirmNewPassword.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtConfirmNewPassword.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtConfirmNewPassword.BorderRadius = 12;
            this.jmtxtConfirmNewPassword.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtConfirmNewPassword.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtConfirmNewPassword.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtConfirmNewPassword.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtConfirmNewPassword.IsPassword = false;
            this.jmtxtConfirmNewPassword.LineThickness = 2;
            this.jmtxtConfirmNewPassword.Location = new System.Drawing.Point(203, 163);
            this.jmtxtConfirmNewPassword.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtConfirmNewPassword.MaxLength = 32767;
            this.jmtxtConfirmNewPassword.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtConfirmNewPassword.Name = "jmtxtConfirmNewPassword";
            this.jmtxtConfirmNewPassword.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtConfirmNewPassword.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtConfirmNewPassword.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtConfirmNewPassword.ReadOnly = false;
            this.jmtxtConfirmNewPassword.Size = new System.Drawing.Size(239, 35);
            this.jmtxtConfirmNewPassword.TabIndex = 37;
            this.jmtxtConfirmNewPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtConfirmNewPassword.TextName = "";
            // 
            // jmtxtNewPassword
            // 
            this.jmtxtNewPassword.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtNewPassword.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtNewPassword.BorderRadius = 12;
            this.jmtxtNewPassword.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtNewPassword.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtNewPassword.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtNewPassword.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtNewPassword.IsPassword = false;
            this.jmtxtNewPassword.LineThickness = 2;
            this.jmtxtNewPassword.Location = new System.Drawing.Point(203, 101);
            this.jmtxtNewPassword.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtNewPassword.MaxLength = 32767;
            this.jmtxtNewPassword.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtNewPassword.Name = "jmtxtNewPassword";
            this.jmtxtNewPassword.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtNewPassword.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtNewPassword.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtNewPassword.ReadOnly = false;
            this.jmtxtNewPassword.Size = new System.Drawing.Size(239, 35);
            this.jmtxtNewPassword.TabIndex = 36;
            this.jmtxtNewPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtNewPassword.TextName = "";
            this.jmtxtNewPassword.Load += new System.EventHandler(this.jmtxtNewPassword_Load);
            // 
            // jmtxtCurrentPassword
            // 
            this.jmtxtCurrentPassword.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtCurrentPassword.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtCurrentPassword.BorderRadius = 13;
            this.jmtxtCurrentPassword.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtCurrentPassword.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtCurrentPassword.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtCurrentPassword.ForeColors = System.Drawing.Color.Black;
            this.jmtxtCurrentPassword.IsPassword = false;
            this.jmtxtCurrentPassword.LineThickness = 2;
            this.jmtxtCurrentPassword.Location = new System.Drawing.Point(203, 44);
            this.jmtxtCurrentPassword.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtCurrentPassword.MaxLength = 32767;
            this.jmtxtCurrentPassword.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtCurrentPassword.Name = "jmtxtCurrentPassword";
            this.jmtxtCurrentPassword.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtCurrentPassword.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtCurrentPassword.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtCurrentPassword.ReadOnly = false;
            this.jmtxtCurrentPassword.Size = new System.Drawing.Size(239, 35);
            this.jmtxtCurrentPassword.TabIndex = 35;
            this.jmtxtCurrentPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtCurrentPassword.TextName = "";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label46.Location = new System.Drawing.Point(17, 178);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(183, 21);
            this.label46.TabIndex = 30;
            this.label46.Text = "Confirm New Password:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label45.Location = new System.Drawing.Point(17, 115);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 21);
            this.label45.TabIndex = 31;
            this.label45.Text = "New Password:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label44.Location = new System.Drawing.Point(17, 54);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(142, 21);
            this.label44.TabIndex = 32;
            this.label44.Text = "Current Password:";
            // 
            // pnlBioData
            // 
            this.pnlBioData.BackColor = System.Drawing.Color.White;
            this.pnlBioData.Controls.Add(this.groupBox3);
            this.pnlBioData.Controls.Add(this.groupBox1);
            this.pnlBioData.Controls.Add(this.button1);
            this.pnlBioData.Location = new System.Drawing.Point(261, 461);
            this.pnlBioData.Name = "pnlBioData";
            this.pnlBioData.Size = new System.Drawing.Size(1125, 366);
            this.pnlBioData.TabIndex = 10;
            this.pnlBioData.Visible = false;
            this.pnlBioData.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlBioData_Paint);
            // 
            // pnlTicketsInfo
            // 
            this.pnlTicketsInfo.BackColor = System.Drawing.Color.White;
            this.pnlTicketsInfo.Controls.Add(this.groupBox7);
            this.pnlTicketsInfo.Controls.Add(this.groupBox6);
            this.pnlTicketsInfo.Location = new System.Drawing.Point(261, 461);
            this.pnlTicketsInfo.Name = "pnlTicketsInfo";
            this.pnlTicketsInfo.Size = new System.Drawing.Size(1125, 366);
            this.pnlTicketsInfo.TabIndex = 31;
            this.pnlTicketsInfo.Visible = false;
            this.pnlTicketsInfo.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTicketsInfo_Paint);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.groupBox7.Location = new System.Drawing.Point(613, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(465, 377);
            this.groupBox7.TabIndex = 49;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "User Ticket Info";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label38.Location = new System.Drawing.Point(26, 47);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(110, 21);
            this.label38.TabIndex = 36;
            this.label38.Text = "Tickets Taken:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(213, 269);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 21);
            this.label39.TabIndex = 47;
            this.label39.Text = "###";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label40.Location = new System.Drawing.Point(26, 101);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(128, 21);
            this.label40.TabIndex = 38;
            this.label40.Text = "Tickets Opened:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label41.Location = new System.Drawing.Point(26, 269);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(119, 21);
            this.label41.TabIndex = 46;
            this.label41.Text = "Tickets Closed:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label42.Location = new System.Drawing.Point(26, 157);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(137, 21);
            this.label42.TabIndex = 40;
            this.label42.Text = "Tickets Escalated:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(213, 214);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(37, 21);
            this.label43.TabIndex = 45;
            this.label43.Text = "###";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(213, 101);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(37, 21);
            this.label48.TabIndex = 41;
            this.label48.Text = "###";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label49.Location = new System.Drawing.Point(26, 214);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(128, 21);
            this.label49.TabIndex = 44;
            this.label49.Text = "Tickets Pending:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(213, 157);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(37, 21);
            this.label50.TabIndex = 42;
            this.label50.Text = "###";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(213, 48);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(37, 21);
            this.label51.TabIndex = 43;
            this.label51.Text = "###";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label27);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.groupBox6.Location = new System.Drawing.Point(8, 10);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(498, 377);
            this.groupBox6.TabIndex = 48;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Department Ticket Info";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(26, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(136, 21);
            this.label8.TabIndex = 36;
            this.label8.Text = "Tickets Assigned:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(213, 269);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(37, 21);
            this.label32.TabIndex = 47;
            this.label32.Text = "###";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(26, 101);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(128, 21);
            this.label24.TabIndex = 38;
            this.label24.Text = "Tickets Opened:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(26, 269);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(119, 21);
            this.label33.TabIndex = 46;
            this.label33.Text = "Tickets Closed:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(26, 157);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(137, 21);
            this.label25.TabIndex = 40;
            this.label25.Text = "Tickets Escalated:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(213, 214);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(37, 21);
            this.label29.TabIndex = 45;
            this.label29.Text = "###";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(213, 101);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 21);
            this.label26.TabIndex = 41;
            this.label26.Text = "###";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(26, 214);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(128, 21);
            this.label30.TabIndex = 44;
            this.label30.Text = "Tickets Pending:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(213, 157);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(37, 21);
            this.label27.TabIndex = 42;
            this.label27.Text = "###";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(213, 48);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 21);
            this.label28.TabIndex = 43;
            this.label28.Text = "###";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.jmtxtPersonalEmail);
            this.groupBox3.Controls.Add(this.jmtxtTelephone2);
            this.groupBox3.Controls.Add(this.jmtxtTelephone1);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(756, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(428, 341);
            this.groupBox3.TabIndex = 35;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Contact Info";
            // 
            // jmtxtPersonalEmail
            // 
            this.jmtxtPersonalEmail.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtPersonalEmail.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtPersonalEmail.BorderRadius = 12;
            this.jmtxtPersonalEmail.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtPersonalEmail.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtPersonalEmail.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtPersonalEmail.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtPersonalEmail.IsPassword = false;
            this.jmtxtPersonalEmail.LineThickness = 2;
            this.jmtxtPersonalEmail.Location = new System.Drawing.Point(122, 92);
            this.jmtxtPersonalEmail.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtPersonalEmail.MaxLength = 32767;
            this.jmtxtPersonalEmail.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtPersonalEmail.Name = "jmtxtPersonalEmail";
            this.jmtxtPersonalEmail.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtPersonalEmail.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtPersonalEmail.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtPersonalEmail.ReadOnly = false;
            this.jmtxtPersonalEmail.Size = new System.Drawing.Size(245, 35);
            this.jmtxtPersonalEmail.TabIndex = 37;
            this.jmtxtPersonalEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtPersonalEmail.TextName = "";
            // 
            // jmtxtTelephone2
            // 
            this.jmtxtTelephone2.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtTelephone2.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtTelephone2.BorderRadius = 11;
            this.jmtxtTelephone2.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtTelephone2.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTelephone2.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTelephone2.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtTelephone2.IsPassword = false;
            this.jmtxtTelephone2.LineThickness = 2;
            this.jmtxtTelephone2.Location = new System.Drawing.Point(122, 53);
            this.jmtxtTelephone2.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtTelephone2.MaxLength = 32767;
            this.jmtxtTelephone2.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtTelephone2.Name = "jmtxtTelephone2";
            this.jmtxtTelephone2.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtTelephone2.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtTelephone2.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtTelephone2.ReadOnly = false;
            this.jmtxtTelephone2.Size = new System.Drawing.Size(245, 35);
            this.jmtxtTelephone2.TabIndex = 38;
            this.jmtxtTelephone2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtTelephone2.TextName = "";
            this.jmtxtTelephone2.Load += new System.EventHandler(this.jmtxtTelephone2_Load);
            // 
            // jmtxtTelephone1
            // 
            this.jmtxtTelephone1.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtTelephone1.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtTelephone1.BorderRadius = 11;
            this.jmtxtTelephone1.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtTelephone1.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTelephone1.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTelephone1.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtTelephone1.IsPassword = false;
            this.jmtxtTelephone1.LineThickness = 2;
            this.jmtxtTelephone1.Location = new System.Drawing.Point(122, 15);
            this.jmtxtTelephone1.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtTelephone1.MaxLength = 32767;
            this.jmtxtTelephone1.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtTelephone1.Name = "jmtxtTelephone1";
            this.jmtxtTelephone1.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtTelephone1.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtTelephone1.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtTelephone1.ReadOnly = false;
            this.jmtxtTelephone1.Size = new System.Drawing.Size(245, 35);
            this.jmtxtTelephone1.TabIndex = 39;
            this.jmtxtTelephone1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtTelephone1.TextName = "";
            this.jmtxtTelephone1.Load += new System.EventHandler(this.jmtxtTelephone1_Load);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(6, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(117, 21);
            this.label23.TabIndex = 37;
            this.label23.Text = "Personal Email:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(6, 67);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(112, 21);
            this.label22.TabIndex = 35;
            this.label22.Text = "Telephone #2:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.jmtxtCountry);
            this.groupBox4.Controls.Add(this.jmtxtParish);
            this.groupBox4.Controls.Add(this.jmtxtStrtNo);
            this.groupBox4.Controls.Add(this.jmtxtTown);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(6, 147);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(413, 182);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Address";
            // 
            // jmtxtCountry
            // 
            this.jmtxtCountry.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtCountry.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtCountry.BorderRadius = 12;
            this.jmtxtCountry.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtCountry.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtCountry.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtCountry.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtCountry.IsPassword = false;
            this.jmtxtCountry.LineThickness = 2;
            this.jmtxtCountry.Location = new System.Drawing.Point(117, 132);
            this.jmtxtCountry.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtCountry.MaxLength = 32767;
            this.jmtxtCountry.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtCountry.Name = "jmtxtCountry";
            this.jmtxtCountry.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtCountry.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtCountry.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtCountry.ReadOnly = false;
            this.jmtxtCountry.Size = new System.Drawing.Size(245, 35);
            this.jmtxtCountry.TabIndex = 43;
            this.jmtxtCountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtCountry.TextName = "";
            // 
            // jmtxtParish
            // 
            this.jmtxtParish.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtParish.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtParish.BorderRadius = 12;
            this.jmtxtParish.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtParish.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtParish.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtParish.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtParish.IsPassword = false;
            this.jmtxtParish.LineThickness = 2;
            this.jmtxtParish.Location = new System.Drawing.Point(116, 93);
            this.jmtxtParish.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtParish.MaxLength = 32767;
            this.jmtxtParish.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtParish.Name = "jmtxtParish";
            this.jmtxtParish.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtParish.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtParish.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtParish.ReadOnly = false;
            this.jmtxtParish.Size = new System.Drawing.Size(245, 35);
            this.jmtxtParish.TabIndex = 42;
            this.jmtxtParish.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtParish.TextName = "";
            // 
            // jmtxtStrtNo
            // 
            this.jmtxtStrtNo.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtStrtNo.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtStrtNo.BorderRadius = 12;
            this.jmtxtStrtNo.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtStrtNo.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtStrtNo.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtStrtNo.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtStrtNo.IsPassword = false;
            this.jmtxtStrtNo.LineThickness = 2;
            this.jmtxtStrtNo.Location = new System.Drawing.Point(117, 13);
            this.jmtxtStrtNo.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtStrtNo.MaxLength = 32767;
            this.jmtxtStrtNo.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtStrtNo.Name = "jmtxtStrtNo";
            this.jmtxtStrtNo.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtStrtNo.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtStrtNo.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtStrtNo.ReadOnly = false;
            this.jmtxtStrtNo.Size = new System.Drawing.Size(245, 35);
            this.jmtxtStrtNo.TabIndex = 40;
            this.jmtxtStrtNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtStrtNo.TextName = "";
            // 
            // jmtxtTown
            // 
            this.jmtxtTown.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtTown.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtTown.BorderRadius = 12;
            this.jmtxtTown.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtTown.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTown.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtTown.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtTown.IsPassword = false;
            this.jmtxtTown.LineThickness = 2;
            this.jmtxtTown.Location = new System.Drawing.Point(116, 55);
            this.jmtxtTown.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtTown.MaxLength = 32767;
            this.jmtxtTown.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtTown.Name = "jmtxtTown";
            this.jmtxtTown.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtTown.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtTown.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtTown.ReadOnly = false;
            this.jmtxtTown.Size = new System.Drawing.Size(245, 35);
            this.jmtxtTown.TabIndex = 41;
            this.jmtxtTown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtTown.TextName = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(6, 147);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 21);
            this.label21.TabIndex = 39;
            this.label21.Text = "Country:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(6, 103);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 21);
            this.label20.TabIndex = 37;
            this.label20.Text = "Parish:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(6, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 21);
            this.label14.TabIndex = 35;
            this.label14.Text = "Town:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(-1, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 21);
            this.label3.TabIndex = 33;
            this.label3.Text = "Street/App No:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(6, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(109, 21);
            this.label37.TabIndex = 31;
            this.label37.Text = "Telephone #1:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.jmNationality);
            this.groupBox1.Controls.Add(this.jmMiddleName);
            this.groupBox1.Controls.Add(this.jmtxtLastName);
            this.groupBox1.Controls.Add(this.jmtxtFirstName);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(9, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(727, 341);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bio Data";
            // 
            // jmNationality
            // 
            this.jmNationality.BackColor = System.Drawing.Color.Transparent;
            this.jmNationality.BorderColor = System.Drawing.Color.Gray;
            this.jmNationality.BorderRadius = 12;
            this.jmNationality.FillColor = System.Drawing.SystemColors.Window;
            this.jmNationality.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmNationality.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmNationality.ForeColors = System.Drawing.Color.Gray;
            this.jmNationality.IsPassword = false;
            this.jmNationality.LineThickness = 2;
            this.jmNationality.Location = new System.Drawing.Point(129, 250);
            this.jmNationality.Margin = new System.Windows.Forms.Padding(4);
            this.jmNationality.MaxLength = 32767;
            this.jmNationality.MouseOnHover = System.Drawing.Color.Empty;
            this.jmNationality.Name = "jmNationality";
            this.jmNationality.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmNationality.OnFocusColor = System.Drawing.Color.Empty;
            this.jmNationality.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmNationality.ReadOnly = false;
            this.jmNationality.Size = new System.Drawing.Size(245, 35);
            this.jmNationality.TabIndex = 40;
            this.jmNationality.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmNationality.TextName = "";
            // 
            // jmMiddleName
            // 
            this.jmMiddleName.BackColor = System.Drawing.Color.Transparent;
            this.jmMiddleName.BorderColor = System.Drawing.Color.Gray;
            this.jmMiddleName.BorderRadius = 12;
            this.jmMiddleName.FillColor = System.Drawing.SystemColors.Window;
            this.jmMiddleName.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmMiddleName.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmMiddleName.ForeColors = System.Drawing.Color.Gray;
            this.jmMiddleName.IsPassword = false;
            this.jmMiddleName.LineThickness = 2;
            this.jmMiddleName.Location = new System.Drawing.Point(129, 129);
            this.jmMiddleName.Margin = new System.Windows.Forms.Padding(4);
            this.jmMiddleName.MaxLength = 32767;
            this.jmMiddleName.MouseOnHover = System.Drawing.Color.Empty;
            this.jmMiddleName.Name = "jmMiddleName";
            this.jmMiddleName.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmMiddleName.OnFocusColor = System.Drawing.Color.Empty;
            this.jmMiddleName.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmMiddleName.ReadOnly = false;
            this.jmMiddleName.Size = new System.Drawing.Size(245, 35);
            this.jmMiddleName.TabIndex = 39;
            this.jmMiddleName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmMiddleName.TextName = "";
            // 
            // jmtxtLastName
            // 
            this.jmtxtLastName.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtLastName.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtLastName.BorderRadius = 12;
            this.jmtxtLastName.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtLastName.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtLastName.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtLastName.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtLastName.IsPassword = false;
            this.jmtxtLastName.LineThickness = 2;
            this.jmtxtLastName.Location = new System.Drawing.Point(131, 72);
            this.jmtxtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtLastName.MaxLength = 32767;
            this.jmtxtLastName.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtLastName.Name = "jmtxtLastName";
            this.jmtxtLastName.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtLastName.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtLastName.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtLastName.ReadOnly = false;
            this.jmtxtLastName.Size = new System.Drawing.Size(245, 35);
            this.jmtxtLastName.TabIndex = 36;
            this.jmtxtLastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jmtxtLastName.TextName = "";
            // 
            // jmtxtFirstName
            // 
            this.jmtxtFirstName.BackColor = System.Drawing.Color.Transparent;
            this.jmtxtFirstName.BorderColor = System.Drawing.Color.Gray;
            this.jmtxtFirstName.BorderRadius = 12;
            this.jmtxtFirstName.FillColor = System.Drawing.SystemColors.Window;
            this.jmtxtFirstName.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtFirstName.Font_Size = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jmtxtFirstName.ForeColors = System.Drawing.Color.Gray;
            this.jmtxtFirstName.IsPassword = false;
            this.jmtxtFirstName.LineThickness = 2;
            this.jmtxtFirstName.Location = new System.Drawing.Point(131, 15);
            this.jmtxtFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.jmtxtFirstName.MaxLength = 32767;
            this.jmtxtFirstName.MouseOnHover = System.Drawing.Color.Empty;
            this.jmtxtFirstName.Name = "jmtxtFirstName";
            this.jmtxtFirstName.OnCursor = System.Windows.Forms.Cursors.IBeam;
            this.jmtxtFirstName.OnFocusColor = System.Drawing.Color.Empty;
            this.jmtxtFirstName.OnFocusFontColor = System.Drawing.Color.Empty;
            this.jmtxtFirstName.ReadOnly = false;
            this.jmtxtFirstName.Size = new System.Drawing.Size(245, 35);
            this.jmtxtFirstName.TabIndex = 32;
            this.jmtxtFirstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.jmtxtFirstName.TextName = "";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(136, 198);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePicker1.Size = new System.Drawing.Size(238, 25);
            this.dateTimePicker1.TabIndex = 31;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(430, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(272, 71);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Gender";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton2.Location = new System.Drawing.Point(172, 35);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(80, 25);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.radioButton1.Location = new System.Drawing.Point(24, 35);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(64, 25);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(6, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 21);
            this.label13.TabIndex = 0;
            this.label13.Text = "First Name:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(6, 254);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(93, 21);
            this.label36.TabIndex = 30;
            this.label36.Text = "Nationality:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(6, 80);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(94, 21);
            this.label34.TabIndex = 28;
            this.label34.Text = "Last Name: ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(6, 198);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(107, 21);
            this.label31.TabIndex = 26;
            this.label31.Text = "Date of Birth:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(6, 139);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(117, 21);
            this.label35.TabIndex = 29;
            this.label35.Text = "Middle Name: ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.button1.FlatAppearance.BorderSize = 3;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(14, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 33);
            this.button1.TabIndex = 25;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // dgvAlerts
            // 
            this.dgvAlerts.BackgroundColor = System.Drawing.Color.White;
            this.dgvAlerts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlerts.Location = new System.Drawing.Point(19, 15);
            this.dgvAlerts.Name = "dgvAlerts";
            this.dgvAlerts.Size = new System.Drawing.Size(1084, 360);
            this.dgvAlerts.TabIndex = 28;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.pbxTicketsCenter);
            this.panel1.Controls.Add(this.pbxMessages);
            this.panel1.Controls.Add(this.pbxAlertsCenter);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.lblDateTime);
            this.panel1.Controls.Add(this.lblUsername);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(228, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1158, 93);
            this.panel1.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Segoe UI", 39.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.label12.Location = new System.Drawing.Point(687, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 101);
            this.label12.TabIndex = 13;
            this.label12.Text = "|";
            // 
            // pbxTicketsCenter
            // 
            this.pbxTicketsCenter.Image = global::VTDI_CSS.Properties.Resources.sticky_notes;
            this.pbxTicketsCenter.Location = new System.Drawing.Point(515, 45);
            this.pbxTicketsCenter.Name = "pbxTicketsCenter";
            this.pbxTicketsCenter.Size = new System.Drawing.Size(30, 29);
            this.pbxTicketsCenter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxTicketsCenter.TabIndex = 11;
            this.pbxTicketsCenter.TabStop = false;
            this.pbxTicketsCenter.Click += new System.EventHandler(this.pbxTicketsCenter_Click);
            // 
            // pbxMessages
            // 
            this.pbxMessages.Image = global::VTDI_CSS.Properties.Resources.mail;
            this.pbxMessages.Location = new System.Drawing.Point(642, 45);
            this.pbxMessages.Name = "pbxMessages";
            this.pbxMessages.Size = new System.Drawing.Size(30, 29);
            this.pbxMessages.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxMessages.TabIndex = 10;
            this.pbxMessages.TabStop = false;
            this.pbxMessages.Click += new System.EventHandler(this.pbxMessages_Click);
            // 
            // pbxAlertsCenter
            // 
            this.pbxAlertsCenter.Image = global::VTDI_CSS.Properties.Resources.notification;
            this.pbxAlertsCenter.Location = new System.Drawing.Point(578, 45);
            this.pbxAlertsCenter.Name = "pbxAlertsCenter";
            this.pbxAlertsCenter.Size = new System.Drawing.Size(30, 29);
            this.pbxAlertsCenter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxAlertsCenter.TabIndex = 9;
            this.pbxAlertsCenter.TabStop = false;
            this.pbxAlertsCenter.Click += new System.EventHandler(this.pbxAlertsCenter_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::VTDI_CSS.Properties.Resources.profile;
            this.pictureBox3.Location = new System.Drawing.Point(1040, 45);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(30, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::VTDI_CSS.Properties.Resources.clock;
            this.pictureBox4.Location = new System.Drawing.Point(727, 45);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 29);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::VTDI_CSS.Properties.Resources.profile1;
            this.pictureBox5.Location = new System.Drawing.Point(6, 20);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(77, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 6;
            this.pictureBox5.TabStop = false;
            // 
            // btnMinimize
            // 
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimize.ForeColor = System.Drawing.Color.DimGray;
            this.btnMinimize.Location = new System.Drawing.Point(1239, 0);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(33, 44);
            this.btnMinimize.TabIndex = 5;
            this.btnMinimize.Text = "-";
            this.btnMinimize.UseVisualStyleBackColor = true;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            this.btnMinimize.MouseEnter += new System.EventHandler(this.btnMinimize_MouseEnter);
            this.btnMinimize.MouseLeave += new System.EventHandler(this.btnMinimize_MouseLeave);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Location = new System.Drawing.Point(89, 33);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 45);
            this.label17.TabIndex = 2;
            this.label17.Text = "Profile";
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.ForeColor = System.Drawing.Color.DimGray;
            this.lblDateTime.Location = new System.Drawing.Point(763, 45);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(143, 25);
            this.lblDateTime.TabIndex = 4;
            this.lblDateTime.Text = "Date And Time";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.DimGray;
            this.lblUsername.Location = new System.Drawing.Point(1076, 45);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(101, 25);
            this.lblUsername.TabIndex = 3;
            this.lblUsername.Text = "Username";
            this.lblUsername.Click += new System.EventHandler(this.lblUsername_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.panel3.Controls.Add(this.pictureBox6);
            this.panel3.Controls.Add(this.btnDashboard);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.btnExit);
            this.panel3.Controls.Add(this.btnUsers);
            this.panel3.Controls.Add(this.btnTickets);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(228, 788);
            this.panel3.TabIndex = 29;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::VTDI_CSS.Properties.Resources.vtdi_logo75;
            this.pictureBox6.Location = new System.Drawing.Point(9, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(119, 75);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // btnDashboard
            // 
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnDashboard.Location = new System.Drawing.Point(12, 133);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(216, 47);
            this.btnDashboard.TabIndex = 11;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDashboard.UseVisualStyleBackColor = true;
            this.btnDashboard.MouseEnter += new System.EventHandler(this.btnDashboard_MouseEnter);
            this.btnDashboard.MouseLeave += new System.EventHandler(this.btnDashboard_MouseLeave);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(134, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 73);
            this.label18.TabIndex = 10;
            this.label18.Text = "CSS ADMIN";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(92, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 24);
            this.label19.TabIndex = 9;
            // 
            // btnExit
            // 
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnExit.Location = new System.Drawing.Point(12, 477);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(216, 47);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.MouseEnter += new System.EventHandler(this.btnExit_MouseEnter);
            this.btnExit.MouseLeave += new System.EventHandler(this.btnExit_MouseLeave);
            // 
            // btnUsers
            // 
            this.btnUsers.FlatAppearance.BorderSize = 0;
            this.btnUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsers.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsers.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnUsers.Location = new System.Drawing.Point(12, 357);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(216, 47);
            this.btnUsers.TabIndex = 6;
            this.btnUsers.Text = "Users";
            this.btnUsers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.MouseEnter += new System.EventHandler(this.btnUsers_MouseEnter);
            this.btnUsers.MouseLeave += new System.EventHandler(this.btnUsers_MouseLeave);
            // 
            // btnTickets
            // 
            this.btnTickets.FlatAppearance.BorderSize = 0;
            this.btnTickets.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTickets.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTickets.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTickets.Location = new System.Drawing.Point(12, 245);
            this.btnTickets.Name = "btnTickets";
            this.btnTickets.Size = new System.Drawing.Size(216, 47);
            this.btnTickets.TabIndex = 5;
            this.btnTickets.Text = "Tickets";
            this.btnTickets.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTickets.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTickets.UseVisualStyleBackColor = true;
            this.btnTickets.MouseEnter += new System.EventHandler(this.btnTickets_MouseEnter);
            this.btnTickets.MouseLeave += new System.EventHandler(this.btnTickets_MouseLeave);
            // 
            // tmrDateTime
            // 
            this.tmrDateTime.Tick += new System.EventHandler(this.tmrDateTime_Tick);
            // 
            // pnlAlerts
            // 
            this.pnlAlerts.BackColor = System.Drawing.Color.White;
            this.pnlAlerts.Controls.Add(this.dgvAlerts);
            this.pnlAlerts.Location = new System.Drawing.Point(261, 461);
            this.pnlAlerts.Name = "pnlAlerts";
            this.pnlAlerts.Size = new System.Drawing.Size(1125, 366);
            this.pnlAlerts.TabIndex = 31;
            this.pnlAlerts.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlAlerts_Paint);
            // 
            // pnlTicketsCenter
            // 
            this.pnlTicketsCenter.BackColor = System.Drawing.Color.White;
            this.pnlTicketsCenter.Controls.Add(this.panel8);
            this.pnlTicketsCenter.Location = new System.Drawing.Point(522, 95);
            this.pnlTicketsCenter.Name = "pnlTicketsCenter";
            this.pnlTicketsCenter.Size = new System.Drawing.Size(278, 212);
            this.pnlTicketsCenter.TabIndex = 39;
            this.pnlTicketsCenter.Visible = false;
            this.pnlTicketsCenter.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTicketsCenter_Paint);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.panel8.Controls.Add(this.label52);
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(278, 35);
            this.panel8.TabIndex = 0;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(12, 9);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(95, 17);
            this.label52.TabIndex = 0;
            this.label52.Text = "Tickets Center";
            // 
            // pnlShadow10
            // 
            this.pnlShadow10.BackColor = System.Drawing.Color.DarkGray;
            this.pnlShadow10.Location = new System.Drawing.Point(525, 98);
            this.pnlShadow10.Name = "pnlShadow10";
            this.pnlShadow10.Size = new System.Drawing.Size(278, 211);
            this.pnlShadow10.TabIndex = 38;
            this.pnlShadow10.Visible = false;
            this.pnlShadow10.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlShadow10_Paint);
            // 
            // pnlAlertsCenter
            // 
            this.pnlAlertsCenter.BackColor = System.Drawing.Color.White;
            this.pnlAlertsCenter.Controls.Add(this.panel7);
            this.pnlAlertsCenter.Location = new System.Drawing.Point(587, 95);
            this.pnlAlertsCenter.Name = "pnlAlertsCenter";
            this.pnlAlertsCenter.Size = new System.Drawing.Size(278, 212);
            this.pnlAlertsCenter.TabIndex = 37;
            this.pnlAlertsCenter.Visible = false;
            this.pnlAlertsCenter.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlAlertsCenter_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.panel7.Controls.Add(this.label53);
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(278, 35);
            this.panel7.TabIndex = 0;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(12, 9);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(88, 17);
            this.label53.TabIndex = 0;
            this.label53.Text = "Alerts Center";
            // 
            // pnlShadow9
            // 
            this.pnlShadow9.BackColor = System.Drawing.Color.DarkGray;
            this.pnlShadow9.Location = new System.Drawing.Point(590, 98);
            this.pnlShadow9.Name = "pnlShadow9";
            this.pnlShadow9.Size = new System.Drawing.Size(278, 211);
            this.pnlShadow9.TabIndex = 36;
            this.pnlShadow9.Visible = false;
            this.pnlShadow9.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlShadow9_Paint);
            // 
            // pnlMessageCenter
            // 
            this.pnlMessageCenter.BackColor = System.Drawing.Color.White;
            this.pnlMessageCenter.Controls.Add(this.panel5);
            this.pnlMessageCenter.Location = new System.Drawing.Point(650, 95);
            this.pnlMessageCenter.Name = "pnlMessageCenter";
            this.pnlMessageCenter.Size = new System.Drawing.Size(278, 212);
            this.pnlMessageCenter.TabIndex = 35;
            this.pnlMessageCenter.Visible = false;
            this.pnlMessageCenter.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlMessageCenter_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.panel5.Controls.Add(this.label54);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(278, 35);
            this.panel5.TabIndex = 0;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(12, 9);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(111, 17);
            this.label54.TabIndex = 0;
            this.label54.Text = "Messages Center";
            // 
            // pnlShadow8
            // 
            this.pnlShadow8.BackColor = System.Drawing.Color.DarkGray;
            this.pnlShadow8.Location = new System.Drawing.Point(653, 99);
            this.pnlShadow8.Name = "pnlShadow8";
            this.pnlShadow8.Size = new System.Drawing.Size(278, 211);
            this.pnlShadow8.TabIndex = 34;
            this.pnlShadow8.Visible = false;
            this.pnlShadow8.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlShadow8_Paint);
            // 
            // pnlUserMenu
            // 
            this.pnlUserMenu.BackColor = System.Drawing.Color.White;
            this.pnlUserMenu.Controls.Add(this.label55);
            this.pnlUserMenu.Controls.Add(this.btnProfile);
            this.pnlUserMenu.Controls.Add(this.btnSettings);
            this.pnlUserMenu.Controls.Add(this.btnLogout);
            this.pnlUserMenu.Controls.Add(this.btnActivityLog);
            this.pnlUserMenu.Location = new System.Drawing.Point(1240, 95);
            this.pnlUserMenu.Name = "pnlUserMenu";
            this.pnlUserMenu.Size = new System.Drawing.Size(181, 170);
            this.pnlUserMenu.TabIndex = 33;
            this.pnlUserMenu.Visible = false;
            this.pnlUserMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlUserMenu_Paint);
            // 
            // label55
            // 
            this.label55.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Silver;
            this.label55.Location = new System.Drawing.Point(0, 110);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(181, 25);
            this.label55.TabIndex = 4;
            this.label55.Text = "--------------------";
            this.label55.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnProfile
            // 
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.DimGray;
            this.btnProfile.Location = new System.Drawing.Point(3, 0);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(175, 32);
            this.btnProfile.TabIndex = 0;
            this.btnProfile.Text = "Profile";
            this.btnProfile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfile.UseVisualStyleBackColor = true;
            this.btnProfile.MouseEnter += new System.EventHandler(this.btnProfile_MouseEnter);
            this.btnProfile.MouseLeave += new System.EventHandler(this.btnProfile_MouseLeave);
            // 
            // btnSettings
            // 
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.DimGray;
            this.btnSettings.Location = new System.Drawing.Point(3, 37);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(175, 32);
            this.btnSettings.TabIndex = 1;
            this.btnSettings.Text = "Settings";
            this.btnSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.MouseEnter += new System.EventHandler(this.btnSettings_MouseEnter);
            this.btnSettings.MouseLeave += new System.EventHandler(this.btnSettings_MouseLeave);
            // 
            // btnLogout
            // 
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.DimGray;
            this.btnLogout.Location = new System.Drawing.Point(3, 132);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(175, 32);
            this.btnLogout.TabIndex = 3;
            this.btnLogout.Text = "Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.MouseEnter += new System.EventHandler(this.btnLogout_MouseEnter);
            this.btnLogout.MouseLeave += new System.EventHandler(this.btnLogout_MouseLeave);
            // 
            // btnActivityLog
            // 
            this.btnActivityLog.FlatAppearance.BorderSize = 0;
            this.btnActivityLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnActivityLog.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActivityLog.ForeColor = System.Drawing.Color.DimGray;
            this.btnActivityLog.Location = new System.Drawing.Point(3, 75);
            this.btnActivityLog.Name = "btnActivityLog";
            this.btnActivityLog.Size = new System.Drawing.Size(175, 32);
            this.btnActivityLog.TabIndex = 2;
            this.btnActivityLog.Text = "Activity Log";
            this.btnActivityLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnActivityLog.UseVisualStyleBackColor = true;
            this.btnActivityLog.MouseEnter += new System.EventHandler(this.btnActivityLog_MouseEnter);
            this.btnActivityLog.MouseLeave += new System.EventHandler(this.btnActivityLog_MouseLeave);
            // 
            // pnlShadow7
            // 
            this.pnlShadow7.BackColor = System.Drawing.Color.DarkGray;
            this.pnlShadow7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlShadow7.Location = new System.Drawing.Point(1244, 98);
            this.pnlShadow7.Name = "pnlShadow7";
            this.pnlShadow7.Size = new System.Drawing.Size(180, 170);
            this.pnlShadow7.TabIndex = 32;
            this.pnlShadow7.Visible = false;
            this.pnlShadow7.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlShadow7_Paint);
            // 
            // jtbtnUpload
            // 
            this.jtbtnUpload.BackColor = System.Drawing.Color.Transparent;
            this.jtbtnUpload.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.jtbtnUpload.BorderColor = System.Drawing.Color.White;
            this.jtbtnUpload.BorderRadius = 25;
            this.jtbtnUpload.ButtonText = "Upload";
            this.jtbtnUpload.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jtbtnUpload.Font_Size = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jtbtnUpload.ForeColors = System.Drawing.SystemColors.Highlight;
            this.jtbtnUpload.HoverBackground = System.Drawing.Color.White;
            this.jtbtnUpload.HoverBorder = System.Drawing.Color.Empty;
            this.jtbtnUpload.HoverFontColor = System.Drawing.SystemColors.Highlight;
            this.jtbtnUpload.LineThickness = 2;
            this.jtbtnUpload.Location = new System.Drawing.Point(1280, 1053);
            this.jtbtnUpload.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.jtbtnUpload.Name = "jtbtnUpload";
            this.jtbtnUpload.Size = new System.Drawing.Size(448, 179);
            this.jtbtnUpload.TabIndex = 41;
            // 
            // jbtnUpload
            // 
            this.jbtnUpload.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.jbtnUpload.BackColor = System.Drawing.Color.Transparent;
            this.jbtnUpload.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(115)))), ((int)(((byte)(223)))));
            this.jbtnUpload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.jbtnUpload.BorderRadius = 7;
            this.jbtnUpload.ButtonText = "Upload";
            this.jbtnUpload.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jbtnUpload.Font_Size = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jbtnUpload.ForeColors = System.Drawing.Color.White;
            this.jbtnUpload.HoverBackground = System.Drawing.Color.White;
            this.jbtnUpload.HoverBorder = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.jbtnUpload.HoverFontColor = System.Drawing.SystemColors.Highlight;
            this.jbtnUpload.LineThickness = 2;
            this.jbtnUpload.Location = new System.Drawing.Point(335, 371);
            this.jbtnUpload.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.jbtnUpload.Name = "jbtnUpload";
            this.jbtnUpload.Size = new System.Drawing.Size(131, 44);
            this.jbtnUpload.TabIndex = 42;
            // 
            // pbxUserImage
            // 
            this.pbxUserImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxUserImage.Location = new System.Drawing.Point(271, 113);
            this.pbxUserImage.Name = "pbxUserImage";
            this.pbxUserImage.Size = new System.Drawing.Size(292, 252);
            this.pbxUserImage.TabIndex = 0;
            this.pbxUserImage.TabStop = false;
            // 
            // frmAdminProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.pnlBioData);
            this.Controls.Add(this.pnlTicketsInfo);
            this.Controls.Add(this.pnlProfileSettings);
            this.Controls.Add(this.jbtnUpload);
            this.Controls.Add(this.jtbtnUpload);
            this.Controls.Add(this.pnlTicketsCenter);
            this.Controls.Add(this.pnlShadow10);
            this.Controls.Add(this.pnlAlertsCenter);
            this.Controls.Add(this.pnlShadow9);
            this.Controls.Add(this.pnlMessageCenter);
            this.Controls.Add(this.pnlShadow8);
            this.Controls.Add(this.pnlUserMenu);
            this.Controls.Add(this.pnlShadow7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pnlDisplayInfo);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pbxUserImage);
            this.Controls.Add(this.pnlAlerts);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAdminProfile";
            this.Text = "frmAdminProfile";
            this.Load += new System.EventHandler(this.frmAdminProfile_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmAdminProfile_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmAdminProfile_MouseMove);
            this.panel2.ResumeLayout(false);
            this.pnlDisplayInfo.ResumeLayout(false);
            this.pnlDisplayInfo.PerformLayout();
            this.pnlProfileSettings.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.pnlBioData.ResumeLayout(false);
            this.pnlTicketsInfo.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlerts)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTicketsCenter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAlertsCenter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.pnlAlerts.ResumeLayout(false);
            this.pnlTicketsCenter.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.pnlAlertsCenter.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pnlMessageCenter.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pnlUserMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxUserImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pbxUserImage;
        private System.Windows.Forms.Panel pnlDisplayInfo;
        private System.Windows.Forms.Panel pnlProfileSettings;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btnBioData;
        private System.Windows.Forms.Button btnAlerts;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DataGridView dgvAlerts;
        private System.Windows.Forms.Panel pnlBioData;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnProfileSettings;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pbxTicketsCenter;
        private System.Windows.Forms.PictureBox pbxMessages;
        private System.Windows.Forms.PictureBox pbxAlertsCenter;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Button btnTickets;
        private System.Windows.Forms.Timer tmrDateTime;
        private System.Windows.Forms.Button btnTicketsInfo;
        private System.Windows.Forms.Panel pnlAlerts;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel pnlTicketsInfo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Panel pnlTicketsCenter;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel pnlShadow10;
        private System.Windows.Forms.Panel pnlAlertsCenter;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Panel pnlShadow9;
        private System.Windows.Forms.Panel pnlMessageCenter;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Panel pnlShadow8;
        private System.Windows.Forms.Panel pnlUserMenu;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnActivityLog;
        private System.Windows.Forms.Panel pnlShadow7;
        private JMetroTextBox.JMetroTextBox jmtxtConfirmNewPassword;
        private JMetroTextBox.JMetroTextBox jmtxtNewPassword;
        private JMetroTextBox.JMetroTextBox jmtxtCurrentPassword;
        private JMetroTextBox.JMetroTextBox jmtxtPersonalEmail;
        private JMetroTextBox.JMetroTextBox jmtxtTelephone2;
        private JMetroTextBox.JMetroTextBox jmtxtTelephone1;
        private JMetroTextBox.JMetroTextBox jmtxtCountry;
        private JMetroTextBox.JMetroTextBox jmtxtParish;
        private JMetroTextBox.JMetroTextBox jmtxtStrtNo;
        private JMetroTextBox.JMetroTextBox jmtxtTown;
        private JMetroTextBox.JMetroTextBox jmNationality;
        private JMetroTextBox.JMetroTextBox jmMiddleName;
        private JMetroTextBox.JMetroTextBox jmtxtLastName;
        private JMetroTextBox.JMetroTextBox jmtxtFirstName;
        private JThinButton.JThinButton jtbtnUpload;
        private JThinButton.JThinButton jbtnUpload;
        private JThinButton.JThinButton jThinButton3;
    }
}